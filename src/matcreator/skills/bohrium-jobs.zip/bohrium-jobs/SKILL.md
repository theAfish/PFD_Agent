---
name: bohrium-jobs
description: Submit and manage computational jobs on Bohrium (bohrium.com) cloud platform using bohr CLI. Supports LAMMPS, VASP, Python, and any containerized workload.
tags: [bohrium, hpc, job-submission, cloud-computing, lammps, vasp, molecular-dynamics]
---

# Bohrium Cloud Job Management

Submit and manage computational jobs on [Bohrium](https://bohrium.com) cloud platform via `bohr` CLI.

## Prerequisites

### 1. Install bohr CLI

- **Windows**: Download from https://bohrium.com/download, place in PATH
- **Linux/macOS**: `curl -fsSL https://bohrium.com/download/bohr | sh`

Verify: `bohr version`

### 2. Login

```bash
bohr login
# Enter email and password interactively
# Token saved to ~/.bohrium/credentials.yaml
```

### 3. Get your project ID

```bash
bohr project list --json
# Note the project ID you want to use
```

## Machine Types (Reference)

Bohrium offers CPU and GPU machines. **Always check current availability with `bohr machine list`** — pricing and inventory change.

### CPU Machines

Format: `c{cores}_m{mem}_cpu` (some have `_H` suffix for high-performance)

| Range | Examples | Price (CNY/h) |
|-------|----------|---------------|
| 2C | c2_m2_cpu ~ c2_m16_cpu | 0.16-0.20 |
| 4C | c4_m4_cpu ~ c4_m32_cpu | 0.32-0.40 |
| 8C | c8_m8_cpu ~ c8_m64_cpu | 0.64-0.80 |
| 12C | c12_m12_cpu ~ c12_m96_cpu | 0.96-1.20 |
| 16C | c16_m16_cpu ~ c16_m128_cpu | 1.28-1.60 |
| 24C | c24_m24_cpu ~ c24_m192_cpu | 1.92-2.40 |
| 32C | c32_m32_cpu ~ c32_m256_cpu | 2.56-3.20 |
| 48C | c48_m176_cpu ~ c48_m384_cpu | 3.84-4.80 |
| 52C | c52_m96_cpu ~ c52_m384_cpu | 4.16 |
| 56C | c56_m160_cpu ~ c56_m224_cpu | 4.48 |
| 64C | c64_m64_cpu ~ c64_m512_cpu | 5.12-7.68 |
| 72C | c72_m288_cpu | 7.20 |
| 96C | c96_m192_cpu ~ c96_m384_cpu | 9.60-11.52 |
| 128C | c128_m512_cpu | 12.80 |

Check current CPU machines:
```bash
bohr machine list -c cpu --json
```

### GPU Machines

Format: `c{cores}_m{mem}_{count} * {GPU_MODEL}` or `{count} * {GPU_MODEL}_{vram}g` (GPU-only)

Available GPU types:

| GPU | VRAM | Price Range (CNY/h) | Configs |
|-----|------|---------------------|---------|
| NVIDIA T4 | 16GB | 2.5-12.0 | 10 |
| NVIDIA V100 | 16/32GB | 4.5-36.0 | 18 |
| NVIDIA A100 | 40/80GB | 10.0-80.0 | 4 |
| NVIDIA 3090 | 24GB | 4.5-36.0 | 4 |
| NVIDIA 4090 | 24GB | 5.5-44.0 | 5 |
| NVIDIA 5090 | 32GB | 1.9 | 1 |
| NVIDIA L4 | 24GB | 5.0-20.0 | 3 |
| NVIDIA L20 | 48GB | 8.0-64.0 | 4 |
| NVIDIA P100 | 16GB | 4.0-32.0 | 4 |
| DCU | 16GB | 1.2-6.0 | 8 |
| FPGA | - | 8.0 | 2 |

Check current GPU machines:
```bash
bohr machine list -c gpu --json
```

**GPU-only vs CPU+GPU**: Entries like `1 * NVIDIA V100_32g` are GPU-only (no CPU/RAM). Entries like `c12_m64_1 * NVIDIA L4` bundle CPU+RAM+GPU. Choose based on your workload's CPU needs.

## Job Submission

### Core command

```bash
bohr job submit \
  --project_id "YOUR_PROJECT_ID" \
  --name "job-name" \
  --machine_type "c8_m32_cpu" \
  --image "registry.dp.tech/dptech/lammps:2023.08.02" \
  --disk_size 20 \
  --job_group_id 0 \
  --command "your command here"
```

### Key parameters

| Parameter | Description | Example |
|-----------|-------------|---------|
| `--project_id` | Your Bohrium project ID | `"12345"` |
| `--name` | Job display name | `"Cu-EOS-test"` |
| `--machine_type` | Machine SKU | `"c8_m32_cpu"` |
| `--image` | Docker image URI | `"registry.dp.tech/dptech/lammps:2023.08.02"` |
| `--disk_size` | Disk in GB | `20` |
| `--job_group_id` | Job group (0=default) | `0` |
| `--command` | Command to run | `"mpirun -np 8 lmp -in in.lammps"` |

### Common Docker images

| Image | Use Case |
|-------|----------|
| `registry.dp.tech/dptech/lammps:2023.08.02` | LAMMPS MD simulations |
| `registry.dp.tech/dptech/deepmd-kit:3.1.3` | LAMMPS + DeePMD-kit |
| `registry.dp.tech/dptech/vasp:5.4.4` | VASP DFT calculations |
| `registry.dp.tech/dptech/gromacs:2023` | GROMACS MD |
| `registry.dp.tech/dptech/python:3.10` | General Python |
| `ubuntu:22.04` | Base OS, install your own |

Find more: https://bohrium.com/docs/images

### Examples

**LAMMPS calculation:**
```bash
bohr job submit \
  --project_id "YOUR_PROJECT_ID" \
  --name "lammps-cu-eos" \
  --machine_type "c8_m32_cpu" \
  --image "registry.dp.tech/dptech/lammps:2023.08.02" \
  --disk_size 20 \
  --job_group_id 0 \
  --command "cd /input && mpirun -np 8 lmp -in in.lammps"
```

**GPU-accelerated LAMMPS:**
```bash
bohr job submit \
  --project_id "YOUR_PROJECT_ID" \
  --name "lammps-gpu" \
  --machine_type "c8_m32_1 * NVIDIA V100_32g" \
  --image "registry.dp.tech/dptech/lammps:2023.08.02" \
  --disk_size 20 \
  --job_group_id 0 \
  --command "cd /input && mpirun -np 8 lmp -sf gpu -pk gpu 1 -in in.lammps"
```

**Python data processing:**
```bash
bohr job submit \
  --project_id "YOUR_PROJECT_ID" \
  --name "python-analysis" \
  --machine_type "c4_m16_cpu" \
  --image "registry.dp.tech/dptech/python:3.10" \
  --disk_size 10 \
  --job_group_id 0 \
  --command "pip install numpy pandas && python /input/analysis.py"
```

## Input/Output Files

### Upload input files

```bash
bohr job upload --job_id JOB_ID --local_path ./input/ --remote_path /input/
```

### Download output files

```bash
bohr job download --job_id JOB_ID --remote_path /input/ --local_path ./output/
```

### Check available files

```bash
bohr job list-files --job_id JOB_ID --path /input/
```

## Job Management

```bash
# List jobs
bohr job list
bohr job list --status running
bohr job list --project_id 12345

# Job details and status
bohr job info --job_id JOB_ID
bohr job status --job_id JOB_ID

# View logs
bohr job log --job_id JOB_ID
bohr job log --job_id JOB_ID --tail 50
bohr job log --job_id JOB_ID --follow

# Cancel/kill job
bohr job cancel --job_id JOB_ID
bohr job kill --job_id JOB_ID
```

## Job Status Lifecycle

```
pending → scheduling → running → finished
                            ↓
                        failed / cancelled
```

## Tips & Pitfalls

- **Always check machine availability** before submitting — popular GPU configs may be out of stock
- **Use `--disk_size` generously** — running out of disk mid-job wastes compute credits
- **Set meaningful job names** — makes tracking easier with many jobs
- **Download results promptly** — completed jobs are retained for a limited time
- **Wrap complex commands in a shell script** — more reliable than long inline `--command` strings
- **GPU jobs need GPU-enabled images** — not all images have CUDA/cuDNN
- **MPI jobs** — use `mpirun -np N` where N matches your machine's CPU cores
- **Memory-intensive jobs** — pick machines with higher memory ratio (e.g., c8_m64 vs c8_m8)
- **`bohr` commands can be slow** — use `timeout 60-120` wrapper for scripted access
- **Prefer CLI flags over JSON config** — JSON submit can fail with internal server errors

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Login fails | `bohr login` again, check credentials |
| Machine not available | Try a different SKU or wait |
| Job stuck in pending | Check quota, try smaller machine |
| No output files | Check logs for errors, verify command ran |
| Out of memory | Use machine with more RAM |
| Disk full | Increase `--disk_size` |

## References

- [references/lammps-input-pitfalls.md](references/lammps-input-pitfalls.md) — LAMMPS input script pitfalls
- [references/bohrium-cli-ref.md](references/bohrium-cli-ref.md) — CLI command reference
- Full docs: https://bohrium.com/docs/cli

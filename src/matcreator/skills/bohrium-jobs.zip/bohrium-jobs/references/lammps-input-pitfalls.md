# LAMMPS Input Script Pitfalls

Collected from Know-Do Graph (skill_lammps) and session debugging.

## Thermo Compute IDs

`thermo_style custom` auto-creates these compute IDs:
- `c_thermo_temp` — temperature
- `c_thermo_pe` — potential energy
- `c_thermo_ke` — kinetic energy
- `c_thermo_etotal` — total energy
- `c_thermo_press` — pressure

**NOT available as compute IDs:**
- `vol` — no `c_thermo_vol`
- `density` — no `c_thermo_density`
- `step` — no `c_thermo_step`

Using these in `fix ave/time` causes:
```
ERROR: Compute ID thermo_vol for fix ave/time does not exist
```

**Fix**: Either omit vol/density from fix ave/time, or define explicit computes:
```lammps
variable vol equal vol
fix 2 all ave/time 100 10 1000 c_thermo_temp c_thermo_pe c_thermo_press v_vol file thermo_avg.dat
```

## Triclinic Box from ASE

ASE's `write('system.data', atoms, format='lammps-data')` may produce triclinic boxes even for cubic crystals when using primitive cells.

Symptom:
```
WARNING: Triclinic box skew is large. LAMMPS will run inefficiently.
```

**Fix**: Use conventional/orthogonal cells:
```python
from ase.build import bulk
cu = bulk('Cu', 'fcc', a=3.615, cubic=True)  # cubic=True → orthogonal cell
```

## NPT Equilibration — Pressure Oscillation

After switching from NVT to NPT, pressure can oscillate wildly for 5-10 ps before converging. This is normal for metals with EAM potentials.

Convergence criteria (from Know-Do Graph):
- Temperature: std/mean < 1%
- Volume: std/mean < 1%
- Energy: stable (no drift)

## EAM Potential File

Cu Mishin EAM potential: `Cu_mishin1.eam.alloy`
- Source: https://raw.githubusercontent.com/lammps/lammps/stable/potentials/Cu_mishin1.eam.alloy
- Citation: Mishin, Phys Rev B, 63, 224106 (2001)
- Must be in working directory when LAMMPS runs
